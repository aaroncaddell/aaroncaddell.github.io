% Aaron Caddell
% 1 Cruise Control, Part 1

clc; clear; close all;

grade = -3;
percentgrade = grade/100;
phi = atan(percentgrade);

g = 9.81;
m = 1400;                 % mass [kg]
rho = 1.25;               % air desnsity [kg/m^3]
Cd = 0.27;                % drag coefficient 
Af = 3;                   % frontal area [m^2]
v1 = [60 65 70 75 80];    % velocity [mph]
v = v1./2.237;            % converting v to m/s 


Traction = 0.5*rho*Cd*Af.*v.^2+m*g*sin(phi);   % Traction Force [N]





