% Aaron Caddell
% 2 Active Suspension Part 3 through 7

clc; clear; close all;

ks = 16000;
ms = 300;
bs = 1000;
mu = 50;
kt = 160000;

A = [0 1 0 0; (-ks/ms) (-bs/ms) (ks/ms) (bs/ms); 0 0 0 1;(ks/mu) (bs/mu) -(ks+kt)/mu (-bs/ms)];

B = [0 0;1 0;0 0;-1 kt/mu];

t = 0:0.015625:50;
u = sin(t);

% The transfer function that relates the acceleration of the sprung mass and the road surface
C = [0 1 0 0];
D = [0 0];
[numA,denA] = ss2tf(A,B,C,D,2);
numA = conv([1 0], numA);
Trans = tf(numA,denA);
figure (1)
% Step Response for Problem 4
subplot(1,3,1);
step(Trans);
% Frequency Response for Problem 5
subplot(1,3,2);
bode(Trans);
% Time Response for Problem 6
subplot(1,3,3);
lsim(Trans,u,t);

% The transfer function that relates the relative deﬂection between the spring mass and the unsprung mass versus the road surface
C = [1 0 -1 0];
D = [0 0];
[numB,denB] = ss2tf(A,B,C,D,2);
Trans = tf(numB,denB);
figure (2)
% Step Response for Problem 4
subplot(1,3,1);
step(Trans);
% Frequency Response for Problem 5
subplot(1,3,2);
bode(Trans);
% Time Response for Problem 6
subplot(1,3,3);
lsim(Trans,u,t);

% The transfer function that relates the tire deﬂection and the road surface
C = [0 0 1 0];
D = [0 -1];
[numC,denC] = ss2tf(A,B,C,D,2);
Trans = tf(numC,denC);
figure (3)
% Step Response for Problem 4
subplot(1,3,1);
step(Trans);
% Frequency Response for Problem 5
subplot(1,3,2);
bode(Trans);
% Time Response for Problem 6
subplot(1,3,3);
lsim(Trans,u,t);

%  The transfer function that relates the sprung mass and the road surface
C = [1 0 0 0];
D = [0 0];
[numD,denD] = ss2tf(A,B,C,D,2);
Trans = tf(numD,denD);
figure (4)
% Step Response for Problem 4
subplot(1,3,1);
step(Trans);
% Frequency Response for Problem 5
subplot(1,3,2);
bode(Trans);
% Time Response for Problem 6
subplot(1,3,3);
lsim(Trans,u,t);
% Parameters for Problem 7
partd = stepinfo(Trans);
r = roots(denD);
disp("Performance Parameters for the Chassis Transfer Function")
disp(partd)
disp("Poles")
disp(r)