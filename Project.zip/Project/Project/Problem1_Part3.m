% Aaron Caddell
% 1 Cruise Control, Part 3

clc; clear; close all;

grade = 0;
percentgrade = grade/100;
phi = atan(percentgrade);

grade1 = -6;
percentgrade1 = grade1/100;
phi1 = atan(percentgrade1);


g = 9.81;
m = 1400;                      % mass [kg]
rho = 1.25;                    % air desnsity [kg/m^3]
Cd = 0.27;                     % drag coefficient 
Af = 3;                        % frontal area [m^2]
mph = 65;                      % velocity [mph]
ve = mph./2.237;               % converting v to m/s
b = 0.5*rho*Cd*Af/m;
Ft = m*g*sin(phi)+(b*m)*ve^2;  % traction force from nonlinear model




tspan = [0 100];
y0 = 0;
F1 = 0;

% linear on 0 percent grade
[t,v] = ode45(@(t,v) -g*phi -2*b*ve*v +F1/m,tspan,y0);
v = v + ve;

% nonlinear on 0 percent grade
y0 = ve;
[t1,v1] = ode45(@(t1,v1) -g*phi -b*v1^2 +Ft/m,tspan,y0);

%linear on -6 percent grade
y0 = 0;
[t2,v2] = ode45(@(t2,v2) -g*phi1 -2*b*ve*v2 +F1/m,tspan,y0);
v2 = v2 + ve;

%nonlinear on -6 percent grade
y0 = ve;
[t3,v3] = ode45(@(t3,v3) -g*phi1 -b*v3^2 +Ft/m,tspan,y0);


plot(t,v,'r')
hold on
plot(t1,v1,'--m')
hold on
plot(t2,v2,'b')
hold on
plot(t3,v3,'--c')
hold off

legend('Linear','Nonlinear','Linear','Nonlinear')


title('Cruise Control Part 3');
ylabel('Velocity'); xlabel('Time');
