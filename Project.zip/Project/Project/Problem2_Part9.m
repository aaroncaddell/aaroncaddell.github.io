% Aaron Caddell
% 2 Active Suspension Part 9

clc; clear; close all;

ks = 16000;
ms = 300;
bs = 1000;
mu = 50;
kt = 160000;

A = [0 1 0 0; (-ks/ms) (-bs/ms) (ks/ms) (bs/ms); 0 0 0 1;(ks/mu) (bs/mu) -(ks+kt)/mu (-bs/ms)];
B = [0 0;1 0;0 0;-1 kt/mu];
C = [1 0 0 0];
D = [0 0];

[num,den] = ss2tf(A,B,C,D,1);
sys = tf(num,den);

PIDtf = tf([.7 2.78 8.0617],1);
ser = series(PIDtf,sys);
feedb = feedback(ser,1);
step(feedb)