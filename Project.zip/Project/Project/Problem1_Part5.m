% Aaron Caddell
% 1 Cruise Control, Part 5

clc; clear; close all;

g = 9.81;
m = 1400;                      % mass [kg]
rho = 1.25;                    % air density [kg/m^3]
Cd = 0.27;                     % drag coefficient 
Af = 3;                        % frontal area [m^2]
mph = 75;                      % velocity [mph]
ve = mph./2.237;               % converting v to m/s
b = 0.5*rho*Cd*Af;

num = 1;
den = [1 2*b*ve];
sys = tf(num,den);
Kp = 235;
Kd = 1;
Ki = 6919.5;

tfpid = tf([Kd Kp Ki],[1 0]);
sys1 = series(tfpid,sys);
sys2 = feedback(sys1,1);

step(sys2);

